import torch
from torch import nn
from torch.nn import functional as F

class CausalSelfAttention(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        assert cfg["n_embd"] % cfg["n_head"] == 0
        self.n_head, self.head_dim = cfg["n_head"], cfg["n_embd"] // cfg["n_head"]
        self.qkv = nn.Linear(cfg["n_embd"], 3 * cfg["n_embd"], bias=False)
        self.proj = nn.Linear(cfg["n_embd"], cfg["n_embd"], bias=False)
        self.attn_drop = nn.Dropout(cfg["dropout"])
        self.resid_drop = nn.Dropout(cfg["dropout"])
        self.register_buffer("mask", torch.tril(torch.ones(cfg["block_size"], cfg["block_size"]))
                             .view(1, 1, cfg["block_size"], cfg["block_size"]), persistent=False)

    def forward(self, x):
        b, t, c = x.shape
        q, k, v = self.qkv(x).chunk(3, dim=-1)
        q = q.view(b,t,self.n_head,self.head_dim).transpose(1,2)
        k = k.view(b,t,self.n_head,self.head_dim).transpose(1,2)
        v = v.view(b,t,self.n_head,self.head_dim).transpose(1,2)
        scores = (q @ k.transpose(-2,-1)) * (self.head_dim ** -0.5)
        scores = scores.masked_fill(self.mask[:,:,:t,:t] == 0, float("-inf"))
        att = self.attn_drop(F.softmax(scores, dim=-1))
        y = (att @ v).transpose(1,2).contiguous().view(b,t,c)
        return self.resid_drop(self.proj(y))

class MLP(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(cfg["n_embd"], 4*cfg["n_embd"]), nn.GELU(),
            nn.Linear(4*cfg["n_embd"], cfg["n_embd"]), nn.Dropout(cfg["dropout"])
        )
    def forward(self, x): return self.net(x)

class Block(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.ln1, self.ln2 = nn.LayerNorm(cfg["n_embd"]), nn.LayerNorm(cfg["n_embd"])
        self.attn, self.mlp = CausalSelfAttention(cfg), MLP(cfg)
    def forward(self, x): return x + self.attn(self.ln1(x)) + self.mlp(self.ln2(x))

class JarvisGPT(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.token_emb = nn.Embedding(cfg["vocab_size"], cfg["n_embd"])
        self.pos_emb = nn.Embedding(cfg["block_size"], cfg["n_embd"])
        self.drop = nn.Dropout(cfg["dropout"])
        self.blocks = nn.Sequential(*[Block(cfg) for _ in range(cfg["n_layer"])])
        self.ln_f = nn.LayerNorm(cfg["n_embd"])
        self.head = nn.Linear(cfg["n_embd"], cfg["vocab_size"], bias=False)
        self.head.weight = self.token_emb.weight
        self.apply(self._init)
    def _init(self, m):
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, 0.0, 0.02)
            if m.bias is not None: nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Embedding): nn.init.normal_(m.weight, 0.0, 0.02)
    def forward(self, idx, targets=None):
        b,t = idx.shape
        if t > self.cfg["block_size"]: raise ValueError("Sequence exceeds block_size")
        pos = torch.arange(t, device=idx.device)
        x = self.drop(self.token_emb(idx) + self.pos_emb(pos))
        x = self.ln_f(self.blocks(x))
        logits = self.head(x)
        loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1)) if targets is not None else None
        return logits, loss
    @torch.no_grad()
    def generate(self, idx, max_new_tokens=100, temperature=0.8, top_k=40, eos_id=None):
        self.eval()
        for _ in range(max_new_tokens):
            idx_cond = idx[:, -self.cfg["block_size"]:]
            logits, _ = self(idx_cond)
            logits = logits[:, -1, :] / max(temperature, 1e-5)
            if top_k:
                vals, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < vals[:, [-1]]] = -float("inf")
            probs = F.softmax(logits, dim=-1)
            nxt = torch.multinomial(probs, num_samples=1)
            idx = torch.cat((idx, nxt), dim=1)
            if eos_id is not None and nxt.item() == eos_id: break
        return idx
