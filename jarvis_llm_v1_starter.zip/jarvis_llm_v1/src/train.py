import argparse, json, math, random
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from tokenizers import Tokenizer
from tqdm import tqdm
from src.model import JarvisGPT

class TokenDataset(Dataset):
    def __init__(self, path, tok, block):
        text = Path(path).read_text(encoding="utf-8")
        ids = tok.encode(text).ids
        self.data = torch.tensor(ids, dtype=torch.long)
        self.block = block
        if len(self.data) <= block:
            raise ValueError(f"Not enough tokens ({len(self.data)}) for block_size {block}")
    def __len__(self): return (len(self.data)-1)//self.block
    def __getitem__(self, i):
        s = i*self.block
        x = self.data[s:s+self.block]
        y = self.data[s+1:s+self.block+1]
        return x, y

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/tiny.json")
    ap.add_argument("--resume", default="")
    a=ap.parse_args()
    cfg=json.loads(Path(a.config).read_text())
    torch.manual_seed(cfg["seed"]); random.seed(cfg["seed"]); np.random.seed(cfg["seed"])
    torch.set_num_threads(max(1, min(4, torch.get_num_threads())))
    tok=Tokenizer.from_file("artifacts/tokenizer/tokenizer.json")
    cfg["vocab_size"]=tok.get_vocab_size()
    train_ds=TokenDataset("data/processed/train.txt",tok,cfg["block_size"])
    val_ds=TokenDataset("data/processed/val.txt",tok,cfg["block_size"])
    train_dl=DataLoader(train_ds,batch_size=cfg["batch_size"],shuffle=True,num_workers=0)
    val_dl=DataLoader(val_ds,batch_size=cfg["batch_size"],shuffle=False,num_workers=0)
    model=JarvisGPT(cfg).cpu()
    opt=torch.optim.AdamW(model.parameters(),lr=cfg["learning_rate"],weight_decay=cfg["weight_decay"])
    step=0
    if a.resume:
        ck=torch.load(a.resume,map_location="cpu",weights_only=False)
        model.load_state_dict(ck["model"]); opt.load_state_dict(ck["optimizer"]); step=ck["step"]
    out=Path("artifacts/checkpoints"); out.mkdir(parents=True,exist_ok=True)
    def evaluate():
        model.eval(); losses=[]
        with torch.no_grad():
            for j,(x,y) in enumerate(val_dl):
                if j>=cfg["eval_batches"]: break
                _,loss=model(x,y); losses.append(loss.item())
        model.train()
        return sum(losses)/max(1,len(losses))
    model.train()
    train_iter=iter(train_dl)
    while step < cfg["max_steps"]:
        opt.zero_grad(set_to_none=True)
        loss_value=0.0
        for _ in range(cfg["grad_accum_steps"]):
            try:
                x,y=next(train_iter)
            except StopIteration:
                train_iter=iter(train_dl)
                x,y=next(train_iter)
            _,loss=model(x,y)
            (loss/cfg["grad_accum_steps"]).backward()
            loss_value += loss.item()/cfg["grad_accum_steps"]
        lr=cfg["learning_rate"] * min((step+1)/max(1,cfg["warmup_steps"]),1.0)
        opt.param_groups[0]["lr"]=lr
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
        opt.step(); step+=1
        if step % 25 == 0: print(f"step {step} train_loss {loss_value:.4f}")
        if step % cfg["eval_interval"] == 0:
            vl=evaluate(); print(f"step {step} val_loss {vl:.4f}")
        if step % cfg["save_interval"] == 0 or step == cfg["max_steps"]:
            payload={"model":model.state_dict(),"optimizer":opt.state_dict(),"step":step,"config":cfg}
            torch.save(payload,out/"latest.pt")
    print("Training complete. Checkpoint: artifacts/checkpoints/latest.pt")
if __name__=="__main__": main()
