import argparse, json, random
from pathlib import Path

ROLES = {"system", "user", "assistant"}

def norm_role(role):
    role = str(role or "").lower()
    if role in ("human", "prompt", "question"): return "user"
    if role in ("gpt", "bot", "model", "completion"): return "assistant"
    return role if role in ROLES else None

def get_content(x):
    if isinstance(x, str): return x.strip()
    if isinstance(x, list):
        parts = []
        for item in x:
            if isinstance(item, dict) and item.get("type") == "text":
                parts.append(str(item.get("text", "")))
            elif isinstance(item, str):
                parts.append(item)
        return "\n".join(parts).strip()
    return ""

def messages_to_text(messages):
    out = []
    for m in messages:
        if not isinstance(m, dict): continue
        role = norm_role(m.get("role") or m.get("from") or m.get("speaker"))
        content = get_content(m.get("content", m.get("value", m.get("text", ""))))
        if role and content:
            out.append(f"<|{role}|>\n{content}\n")
    if out:
        return "<|bos|>\n" + "".join(out) + "<|eos|>\n"
    return ""

def records(obj):
    if isinstance(obj, list):
        for x in obj: yield from records(x)
    elif isinstance(obj, dict):
        if isinstance(obj.get("messages"), list):
            yield messages_to_text(obj["messages"])
        elif isinstance(obj.get("conversations"), list):
            conv = obj["conversations"]
            if conv and all(isinstance(x, dict) for x in conv):
                yield messages_to_text(conv)
            else:
                yield from records(conv)
        elif "question" in obj and "answer" in obj:
            q, a = get_content(obj["question"]), get_content(obj["answer"])
            if q and a:
                yield f"<|bos|>\n<|user|>\n{q}\n<|assistant|>\n{a}\n<|eos|>\n"
        elif "text" in obj:
            t = get_content(obj["text"])
            if t: yield f"<|bos|>\n{t}\n<|eos|>\n"
        else:
            for v in obj.values():
                if isinstance(v, (dict, list)): yield from records(v)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="data/raw")
    ap.add_argument("--output", default="data/processed")
    ap.add_argument("--val-ratio", type=float, default=0.02)
    args = ap.parse_args()
    src, dst = Path(args.input), Path(args.output)
    dst.mkdir(parents=True, exist_ok=True)
    docs, seen = [], set()
    for p in sorted(src.rglob("*.json")):
        try:
            obj = json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"SKIP {p}: {e}")
            continue
        for doc in records(obj):
            doc = doc.strip()
            if len(doc) < 8 or doc in seen: continue
            seen.add(doc); docs.append(doc)
    random.Random(42).shuffle(docs)
    if len(docs) < 2:
        raise SystemExit("No usable records found. Check JSON format and parser.")
    nval = max(1, int(len(docs) * args.val_ratio))
    val, train = docs[:nval], docs[nval:]
    (dst/"train.txt").write_text("\n".join(train), encoding="utf-8")
    (dst/"val.txt").write_text("\n".join(val), encoding="utf-8")
    stats = {"files": len(list(src.rglob("*.json"))), "unique_records": len(docs),
             "train_records": len(train), "val_records": len(val),
             "train_chars": sum(map(len, train)), "val_chars": sum(map(len, val))}
    (dst/"stats.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    print(json.dumps(stats, indent=2))
if __name__ == "__main__": main()
