import platform, os, torch
print("Platform:", platform.platform())
print("Processor:", platform.processor() or "unknown")
print("Logical CPUs:", os.cpu_count())
print("PyTorch:", torch.__version__)
print("Threads:", torch.get_num_threads())
print("CPU-only:", not torch.cuda.is_available())
try:
    print("CPU flags:")
    for line in open("/proc/cpuinfo"):
        if line.lower().startswith("flags"):
            print(line.strip()); break
except OSError:
    print("CPU flags unavailable on this OS")
