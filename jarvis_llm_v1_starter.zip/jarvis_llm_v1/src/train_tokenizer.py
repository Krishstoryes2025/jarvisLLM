import argparse
from pathlib import Path
from tokenizers import Tokenizer, models, trainers, pre_tokenizers, decoders, normalizers

SPECIAL = ["<|pad|>", "<|unk|>", "<|bos|>", "<|eos|>",
           "<|system|>", "<|user|>", "<|assistant|>"]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="data/processed/train.txt")
    ap.add_argument("--output", default="artifacts/tokenizer")
    ap.add_argument("--vocab-size", type=int, default=8000)
    a = ap.parse_args()
    out = Path(a.output); out.mkdir(parents=True, exist_ok=True)
    tok = Tokenizer(models.BPE(unk_token="<|unk|>"))
    tok.normalizer = normalizers.NFC()
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tok.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(vocab_size=a.vocab_size, min_frequency=2,
                                  special_tokens=SPECIAL, initial_alphabet=pre_tokenizers.ByteLevel.alphabet())
    tok.train([a.input], trainer)
    tok.save(str(out/"tokenizer.json"))
    print("Tokenizer saved:", out/"tokenizer.json")
    print("Actual vocabulary:", tok.get_vocab_size())
    for sample in ["नमस्ते Jarvis", "Hello, how are you?", "तुम कैसे हो bro?"]:
        enc = tok.encode(sample)
        print(repr(sample), "=>", enc.ids, "=>", tok.decode(enc.ids))
if __name__ == "__main__": main()
