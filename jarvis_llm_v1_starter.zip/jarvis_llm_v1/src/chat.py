import argparse, json
from pathlib import Path
import torch
from tokenizers import Tokenizer
from src.model import JarvisGPT

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--checkpoint",default="artifacts/checkpoints/latest.pt")
    ap.add_argument("--tokenizer",default="artifacts/tokenizer/tokenizer.json")
    ap.add_argument("--max-new-tokens",type=int,default=100)
    a=ap.parse_args()
    ck=torch.load(a.checkpoint,map_location="cpu",weights_only=False)
    cfg=ck["config"]; tok=Tokenizer.from_file(a.tokenizer)
    model=JarvisGPT(cfg); model.load_state_dict(ck["model"]); model.eval()
    bos=tok.token_to_id("<|bos|>"); eos=tok.token_to_id("<|eos|>")
    print("Jarvis LLM v1 (experimental). Type /exit to quit.")
    history=""
    while True:
        q=input("\nYou: ").strip()
        if q=="/exit": break
        prompt=history+f"<|user|>\n{q}\n<|assistant|>\n"
        ids=tok.encode(prompt).ids
        if bos is not None: ids=[bos]+ids
        x=torch.tensor([ids[-cfg["block_size"]:]],dtype=torch.long)
        with torch.no_grad():
            y=model.generate(x,a.max_new_tokens,temperature=0.8,top_k=40,eos_id=eos)
        new=y[0].tolist()[len(x[0]):]
        answer=tok.decode(new).split("<|eos|>")[0].split("<|user|>")[0].strip()
        print("Jarvis:",answer)
        history=prompt+answer+"\n"
        # Keep recent turns only to fit context.
        if len(tok.encode(history).ids)>cfg["block_size"]//2:
            history=""
if __name__=="__main__": main()
