# Jarvis LLM v1 — CPU-first from-scratch Transformer

This is a **starter training project**, not a pretrained or already-trained model.
It creates a small decoder-only Transformer from random initialization, trains a custom
BPE tokenizer on your corpus, prepares JSON conversations, trains the model, and runs
local text generation.

## Target machine
- Intel Core i5 3rd generation (exact SKU/ISA not yet known)
- 16 GB RAM, SSD, no GPU
- Linux recommended; Debian 13 XFCE is a good lightweight option
- Start with the `tiny` config (about 2M parameters) to validate the pipeline. Then try `configs/jarvis_8m.json` (roughly 8M parameters) if RAM and speed permit. CPU training will be slow; this is an experiment, not
  a route to ChatGPT-level capability from 500 MB of conversation data.

## Important expectations
- 500 MB of JSON is not necessarily 500 MB of useful text. Inspect the cleaned corpus.
- A model trained from scratch only learns what the corpus teaches it. A narrow chat
  dataset will produce a narrow model and may not teach general knowledge.
- The initial 10M-ish model is for validating the pipeline. It may produce poor or
  repetitive answers. Increase size only after measuring tokens, loss, RAM and speed.
- This project does not automatically convert a custom architecture to GGUF. GGUF
  export requires a compatible architecture/conversion path; use the included PyTorch
  inference first. Do not assume llama.cpp can load this custom model directly.

## 1. Put data in place
Copy your 10 JSON files into `data/raw/`. The parser accepts common shapes:
- OpenAI-style `messages: [{role, content}]`
- `conversations` arrays
- `question` + `answer`
- plain text records with `text`

If your JSON schema is different, add a parser in `src/prepare_data.py`.
Do not upload private or sensitive conversations unless you are comfortable using them
for model training.

## 2. Install (Linux)
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

For older CPUs, install the CPU PyTorch wheel appropriate to your OS from
https://pytorch.org/get-started/locally/ if the default pip wheel is unsuitable.

## 3. Prepare corpus and tokenizer
```bash
python -m src.prepare_data --input data/raw --output data/processed
python -m src.train_tokenizer --input data/processed/train.txt --output artifacts/tokenizer --vocab-size 8000
```

Check `data/processed/stats.json`. The tokenizer is custom-trained on your corpus.
Special tokens are:
`<|pad|>`, `<|unk|>`, `<|bos|>`, `<|eos|>`, `<|user|>`, `<|assistant|>`, `<|system|>`.

## 4. Train from scratch
```bash
python -m src.train --config configs/tiny.json\n# After successful smoke test, try:\npython -m src.train --config configs/jarvis_8m.json
```
Training checkpoints go to `artifacts/checkpoints/`. Start with a small batch and
short context on this CPU. Training can take many hours or days depending on corpus,
CPU model, sequence length and number of steps. Keep the machine cool and monitor RAM
and temperature.

## 5. Chat
```bash
python -m src.chat --checkpoint artifacts/checkpoints/latest.pt \
  --tokenizer artifacts/tokenizer/tokenizer.json
```

## 6. CPU tuning
Run:
```bash
lscpu
python -m src.benchmark
```
The exact i5 model matters. 3rd-gen i5 commonly has AVX but not AVX2; never compile
with `-march=native` on one machine and assume the binary is portable to another.
The included PyTorch model uses CPU operations and does not require AVX2 explicitly.

## Dataset safety and quality
- Remove passwords, API keys, private identifiers, and conversations you do not own.
- Deduplicate near-identical records.
- Keep validation data separate; do not train on validation examples.
- Do not split a single conversation across train and validation.
- Avoid treating assistant answers as user prompts; preserve role markers.
