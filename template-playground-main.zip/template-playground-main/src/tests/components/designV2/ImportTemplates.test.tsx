import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import JSZip from 'jszip';
import ImportTemplates from '../../../components/designV2/ImportTemplates';
import useAppStore, { importedTemplateName } from '../../../store/store';
import useDesignV2Store from '../../../store/designV2Store';
import { STEPS } from '../../../types/designV2.types';
import { IMPORT } from '../../../components/designV2/constants';
import * as blank from '../../../samples/blank';

const makeArchive = async (cicero = '^3.0.0', name = 'imported-nda') => {
  const zip = new JSZip();
  zip.file('package.json', JSON.stringify({ name, version: '1.0.0', accordproject: { template: 'contract', cicero } }));
  zip.file('text/grammar.tem.md', 'Hello {{exampleField}}');
  zip.file('model/model.cto', blank.MODEL);
  zip.file('data.json', JSON.stringify(blank.DATA));
  return zip.generateAsync({ type: 'uint8array' });
};

/** Building or reading an archive loads Concerto, which is slow on a busy CI runner. */
const SLOW = { timeout: 15_000 };

describe('ImportTemplates', () => {
  // Like the store's, it names the template synchronously, then renders and compiles.
  const nameIt = ({ name }: { name: string }) => useAppStore.setState({ sampleName: importedTemplateName(name) });
  const loadImportedTemplate = vi.fn((template: { name: string }) => {
    nameIt(template);
    return Promise.resolve();
  });
  beforeEach(() => {
    loadImportedTemplate.mockClear();
    useAppStore.setState({ sampleName: 'Previous Template' });
    useAppStore.setState({ loadImportedTemplate });
    useDesignV2Store.setState({ selectedTemplate: null });
    useDesignV2Store.getState().start();
  });
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('loads an uploaded .cta and opens the next step', async () => {
    render(<ImportTemplates />);
    const bytes = await makeArchive();
    const file = new File([bytes as BlobPart], 'nda.cta');
    Object.defineProperty(file, 'arrayBuffer', { value: () => Promise.resolve(bytes.buffer) });
    fireEvent.change(screen.getByLabelText(IMPORT.upload.inputLabel), { target: { files: [file] } });
    await waitFor(() => expect(loadImportedTemplate).toHaveBeenCalled(), SLOW);
    expect((loadImportedTemplate.mock.calls as unknown[][])[0][0]).toMatchObject({ name: 'Imported Nda', templateMarkdown: 'Hello {{exampleField}}' });
    expect(useDesignV2Store.getState().selectedTemplate).toBe('Imported Nda');
    expect(useDesignV2Store.getState().view).toBe(STEPS[1].id);
  }, 30_000);

  it('selects an import named like a bundled sample by the name the store gives it', async () => {
    render(<ImportTemplates />);
    // Cicero names it "Consulting Agreement", as the bundled sample is named.
    const bytes = await makeArchive('^3.0.0', 'consulting-agreement');
    const file = new File([bytes as BlobPart], 'consulting.cta');
    Object.defineProperty(file, 'arrayBuffer', { value: () => Promise.resolve(bytes.buffer) });
    fireEvent.change(screen.getByLabelText(IMPORT.upload.inputLabel), { target: { files: [file] } });
    await waitFor(() => expect(loadImportedTemplate).toHaveBeenCalled(), SLOW);
    expect((loadImportedTemplate.mock.calls as unknown[][])[0][0]).toMatchObject({ name: 'Consulting Agreement' });
    await waitFor(() => expect(useDesignV2Store.getState().selectedTemplate).toBe('Consulting Agreement (imported)'));
  }, 30_000);

  it('does not change the template when the file is not an archive', async () => {
    render(<ImportTemplates />);
    const file = new File(['nope'], 'x.cta');
    Object.defineProperty(file, 'arrayBuffer', { value: () => Promise.resolve(new TextEncoder().encode('nope').buffer) });
    fireEvent.change(screen.getByLabelText(IMPORT.upload.inputLabel), { target: { files: [file] } });
    await waitFor(() => expect(screen.getByText(/not a template archive/)).toBeInTheDocument(), SLOW);
    expect(loadImportedTemplate).not.toHaveBeenCalled();
  }, 30_000);

  it('lists only compatible templates, filters like the hosted library and imports the chosen one', async () => {
    const bytes = await makeArchive();
    const cicero1 = await makeArchive('^1.0.0');
    const fetchMock = vi.fn((url: string) =>
      Promise.resolve(
        url.endsWith('template-library.json')
          ? { ok: true, json: () => Promise.resolve({
              'helloworld@0.14.0': { name: 'helloworld', version: '0.14.0', description: 'Ergo hello', ciceroVersion: '^0.20.0', tags: ['reference'] },
              'helloworld@1.0.0': { name: 'helloworld', displayName: 'Hello World', version: '1.0.0', description: 'Say hello', ciceroVersion: '^2.0.0', type: 1, tags: ['reference'] },
              'late-fees@0.9.0': { name: 'late-fees', displayName: 'Late Fees', version: '0.9.0', description: 'Penalty clause', ciceroVersion: '^1.0.0', type: 0, tags: ['finance'] },
              'late-fees@1.0.0': { name: 'late-fees', displayName: 'Late Fees', version: '1.0.0', description: 'Penalty clause', ciceroVersion: '^2.0.0', type: 0, tags: ['finance'] },
              'old@1.0.0': { name: 'old', displayName: 'Old One', version: '1.0.0', description: 'Retired', ciceroVersion: '^2.0.0', archived: true, tags: ['finance'] },
              // Indexed as ^2.0.0, but its archive targets Cicero 1.x, which Cicero refuses.
              'mislabelled@1.0.0': { name: 'mislabelled', displayName: 'Mislabelled', version: '1.0.0', description: 'Index says 2', ciceroVersion: '^2.0.0', tags: ['finance'] },
            }) }
          : { ok: true, arrayBuffer: () => Promise.resolve((url.includes('mislabelled') ? cicero1 : bytes).buffer) }
      )
    );
    vi.stubGlobal('fetch', fetchMock);
    render(<ImportTemplates />);
    fireEvent.click(screen.getByRole('button', { name: IMPORT.library.button }));
    // Newest compatible version only; the Ergo-era 0.14.0, the archived template and the Cicero 1.x archive are hidden.
    expect(await screen.findByText(IMPORT.library.count(2), undefined, SLOW)).toBeInTheDocument();
    expect(screen.queryByText('Ergo hello')).not.toBeInTheDocument();
    expect(screen.queryByText('Old One')).not.toBeInTheDocument();
    expect(screen.queryByText('Mislabelled')).not.toBeInTheDocument();
    expect(screen.getByRole('region', { name: 'finance' })).toBeInTheDocument();
    expect(screen.getByRole('region', { name: 'reference' })).toBeInTheDocument();

    fireEvent.click(screen.getByText(IMPORT.library.showArchived));
    expect(await screen.findByText('Old One', undefined, SLOW)).toBeInTheDocument();
    expect(screen.getByRole('region', { name: IMPORT.library.archived })).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText(IMPORT.library.search), { target: { value: 'penalty' } });
    expect(screen.queryByText('Hello World')).not.toBeInTheDocument();
    fireEvent.click(await screen.findByRole('button', { name: IMPORT.library.pick('Late Fees', '1.0.0') }, SLOW));
    await waitFor(() => expect(loadImportedTemplate).toHaveBeenCalled(), SLOW);
    expect(fetchMock).toHaveBeenCalledWith('https://templates.accordproject.org/archives/late-fees@1.0.0.cta');
  }, 30_000);
});
