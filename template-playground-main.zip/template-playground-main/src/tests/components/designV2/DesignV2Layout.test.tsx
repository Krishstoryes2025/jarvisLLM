import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { act } from 'react-dom/test-utils';
import { message } from 'antd';
import { MemoryRouter } from 'react-router-dom';
import '@testing-library/jest-dom';
import DesignV2Layout from '../../../components/designV2/DesignV2Layout';
import { DEFAULT_TEMPLATE } from '../../../components/designV2/usePickTemplate';
import { FOOTER, HEADER, HELP_RAIL, PREVIEW, RAIL, START_SAMPLES, URLS, WELCOME, sampleNameFor } from '../../../components/designV2/constants';
import useAppStore, { SHARED_TEMPLATE_NAME } from '../../../store/store';
import useDesignV2Store from '../../../store/designV2Store';
import { FIRST_STEP, STEP_ID } from '../../../types/designV2.types';
import * as latePayment from '../../../samples/latePaymentPenalty';
import * as playground from '../../../samples/playground';
import { V2_PALETTE } from '../../../components/designV2/theme';
import type { ComponentProps } from 'react';
import { theme as antdTheme, type ConfigProvider, type ThemeConfig } from 'antd';

type ConfigProviderProps = ComponentProps<typeof ConfigProvider>;

/** Every theme the app passes to antd's ConfigProvider, in render order. */
const configProviderThemes = vi.hoisted(() => [] as ThemeConfig[]);

vi.mock('antd', async (importOriginal) => {
  const actual = await importOriginal<typeof import('antd')>();
  const { createElement } = await import('react');
  const RecordingConfigProvider = Object.assign(
    (props: ConfigProviderProps) => {
      if (props.theme) configProviderThemes.push(props.theme);
      return createElement(actual.ConfigProvider, props);
    },
    actual.ConfigProvider
  );
  return { ...actual, ConfigProvider: RecordingConfigProvider };
});

/*
 * Covers entering the flow: "Start building" must land on the first gallery
 * card, so the editor steps never open on the app store's startup sample.
 * Also the hero's "How it works" link, where the Preview toggle lives, and
 * the gate in front of Simulate: moving there compiles the logic, and a
 * compile error keeps the user where they are.
 */
vi.mock('@monaco-editor/react', () => ({
  useMonaco: () => null,
  Editor: ({ language }: { language: string }) => <div data-testid={`monaco-${language}`} />,
}));

// The store's own loadSample, kept before the tests below swap in stand-ins.
const realLoadSample = useAppStore.getState().loadSample;

/** A promise with its resolve handle, to finish a compile when the test says so. */
const deferredCompile = () => {
  let finish!: () => void;
  const done = new Promise<void>((resolve) => { finish = resolve; });
  return { done, finish };
};

const renderLayout = () =>
  render(
    <MemoryRouter>
      <DesignV2Layout />
    </MemoryRouter>
  );

describe('DesignV2Layout theme', () => {
  /** The theme the layout's own ConfigProvider (v2 font) received on its latest render; nested providers are skipped. */
  const providedTheme = () => {
    const v2Themes = configProviderThemes.filter((t) => t.token?.fontFamily === V2_PALETTE.fontFamily);
    expect(v2Themes.length).toBeGreaterThan(0);
    return v2Themes[v2Themes.length - 1];
  };

  beforeEach(() => {
    configProviderThemes.length = 0;
    useAppStore.setState({ backgroundColor: '#ffffff', textColor: '#121212' });
    document.documentElement.setAttribute('data-theme', 'light');
    useDesignV2Store.setState({ view: 'welcome' });
  });

  it('gives antd the light algorithm and the v2 palette by default', () => {
    renderLayout();

    expect(providedTheme().algorithm).toBe(antdTheme.defaultAlgorithm);
    expect(providedTheme().token).toMatchObject({ colorPrimary: V2_PALETTE.teal, colorTextBase: V2_PALETTE.ink });
  });

  it('follows the app theme: dark algorithm and dark tokens, and back again', () => {
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: RAIL.settings }));

    fireEvent.click(screen.getByRole('switch', { name: 'Toggle dark mode' }));
    // The CSS shell reads the same attribute the app sets on <html>.
    expect(document.documentElement).toHaveAttribute('data-theme', 'dark');
    expect(providedTheme().algorithm).toBe(antdTheme.darkAlgorithm);
    expect(providedTheme().token).toMatchObject({ colorPrimary: '#50c5c7', colorLink: '#72d4d3' });
    expect(providedTheme().token).not.toHaveProperty('colorTextBase');

    fireEvent.click(screen.getByRole('switch', { name: 'Toggle dark mode' }));
    expect(document.documentElement).toHaveAttribute('data-theme', 'light');
    expect(providedTheme().algorithm).toBe(antdTheme.defaultAlgorithm);
    expect(providedTheme().token).toMatchObject({ colorPrimary: V2_PALETTE.teal });
  });
});

describe('DesignV2Layout — Start building', () => {
  const loadSample = vi.fn().mockResolvedValue(undefined);

  beforeEach(() => {
    vi.clearAllMocks();
    // The untouched startup sample.
    useAppStore.setState({
      loadSample,
      sampleName: playground.NAME,
      editorValue: playground.TEMPLATE,
      editorModelCto: playground.MODEL,
      editorAgreementData: JSON.stringify(playground.DATA, null, 2),
      editorLogicTs: '',
    });
    useDesignV2Store.setState({ view: 'welcome', selectedTemplate: null });
  });

  it('keeps edits made in the classic playground instead of loading the first card', () => {
    useAppStore.setState({ editorValue: 'Edited in classic {{name}}' });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: `${WELCOME.start} →` }));

    expect(useDesignV2Store.getState().view).toBe(FIRST_STEP);
    expect(useDesignV2Store.getState().selectedTemplate).toBe(playground.NAME);
    expect(useAppStore.getState().editorValue).toBe('Edited in classic {{name}}');
    expect(loadSample).not.toHaveBeenCalled();
  });

  it('keeps a sample loaded in the classic playground and selects its gallery card', () => {
    const card = START_SAMPLES[1];
    useAppStore.setState({ sampleName: card.sampleName });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: `${WELCOME.start} →` }));

    expect(useDesignV2Store.getState().selectedTemplate).toBe(card.name);
    expect(loadSample).not.toHaveBeenCalled();
  });

  it('picks and loads the first gallery card when nothing was picked', () => {
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: `${WELCOME.start} →` }));

    expect(useDesignV2Store.getState().view).toBe(FIRST_STEP);
    expect(useDesignV2Store.getState().selectedTemplate).toBe(DEFAULT_TEMPLATE);
    expect(DEFAULT_TEMPLATE).toBe(START_SAMPLES[0].name);
    expect(loadSample).toHaveBeenCalledWith(sampleNameFor(DEFAULT_TEMPLATE));
  });

  it('keeps a template that was already picked', () => {
    useDesignV2Store.setState({ selectedTemplate: START_SAMPLES[1].name });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: `${WELCOME.start} →` }));

    expect(useDesignV2Store.getState().view).toBe(FIRST_STEP);
    expect(useDesignV2Store.getState().selectedTemplate).toBe(START_SAMPLES[1].name);
    expect(loadSample).not.toHaveBeenCalled();
  });

  it('keeps a template opened from a share link instead of loading the first card', () => {
    useAppStore.setState({ sampleName: SHARED_TEMPLATE_NAME });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: `${WELCOME.start} →` }));

    expect(useDesignV2Store.getState().view).toBe(FIRST_STEP);
    expect(useDesignV2Store.getState().selectedTemplate).toBe(SHARED_TEMPLATE_NAME);
    expect(loadSample).not.toHaveBeenCalled();
  });

  it('"How it works" opens the docs site in a new tab', () => {
    renderLayout();
    const link = screen.getByRole('link', { name: WELCOME.howItWorks });
    expect(link).toHaveAttribute('href', URLS.templateDocs);
    expect(link).toHaveAttribute('target', '_blank');
    expect(link).toHaveAttribute('rel', 'noopener noreferrer');
  });

  it('says it is a playground, not an IDE, and links developers to the VS Code tutorial', () => {
    renderLayout();
    expect(screen.getByText(WELCOME.ideNote, { exact: false })).toBeInTheDocument();
    const link = screen.getByRole('link', { name: WELCOME.ideNoteLink });
    expect(link).toHaveAttribute('href', URLS.vscodeTutorial);
    expect(link).toHaveAttribute('target', '_blank');
    expect(link).toHaveAttribute('rel', 'noopener noreferrer');
  });
});

describe('DesignV2Layout — Write | Preview switch', () => {
  beforeEach(() => {
    useAppStore.setState({ loadSample: vi.fn().mockResolvedValue(undefined) });
    useDesignV2Store.setState({ selectedTemplate: START_SAMPLES[0].name, previewOpen: false, helpRailOpen: true });
  });

  it('is not in the header on the Start step', () => {
    useDesignV2Store.setState({ view: FIRST_STEP });
    renderLayout();
    expect(screen.queryByRole('radio', { name: PREVIEW.preview })).not.toBeInTheDocument();
  });

  it.each([STEP_ID.text, STEP_ID.modelData])(
    'on step %s Preview shows the agreement in the editors\' place, keeping the help rail',
    async (view) => {
      useDesignV2Store.setState({ view });
      useAppStore.setState({ agreementHtml: '<h1>Consulting Agreement</h1>' });
      renderLayout();
      expect(screen.queryByRole('region', { name: PREVIEW.ariaLabel })).not.toBeInTheDocument();
      // The editors load lazily (Suspense), so wait for them.
      const editors = await screen.findAllByTestId(/^monaco-/);
      expect(editors.length).toBeGreaterThan(0);

      fireEvent.click(screen.getByRole('radio', { name: PREVIEW.preview }));
      expect(useDesignV2Store.getState().previewOpen).toBe(true);
      expect(screen.getByRole('region', { name: PREVIEW.ariaLabel })).toBeInTheDocument();
      expect(screen.getByRole('heading', { name: 'Consulting Agreement' })).toBeInTheDocument();
      // The editors are hidden, not unmounted, so their undo history survives.
      for (const editor of editors) {
        expect(editor).toBeInTheDocument();
        expect(editor).not.toBeVisible();
      }
      expect(screen.getByRole('complementary', { name: HELP_RAIL.ariaLabel })).toBeInTheDocument();

      fireEvent.click(screen.getByRole('radio', { name: PREVIEW.write }));
      expect(useDesignV2Store.getState().previewOpen).toBe(false);
      expect(screen.queryByRole('region', { name: PREVIEW.ariaLabel })).not.toBeInTheDocument();
      // The very same editor instances are back: nothing was remounted.
      expect(screen.getAllByTestId(/^monaco-/)).toEqual(editors);
      for (const editor of editors) expect(editor).toBeVisible();
    },
  );
});

describe('DesignV2Layout — moving to Simulate', () => {
  /** setLogicTs stand-in: commits the source and reports the given outcome. */
  const compileTo = (outcome: 'ok' | 'error') =>
    vi.fn(async (ts: string) => {
      await Promise.resolve();
      useAppStore.setState(
        outcome === 'ok'
          ? { logicTs: ts, editorLogicTs: ts, compiledModelCto: useAppStore.getState().modelCto, compiledLogicJs: 'js', compilationErrors: [] }
          : { logicTs: ts, editorLogicTs: ts, compiledModelCto: useAppStore.getState().modelCto, compiledLogicJs: null, compilationErrors: [{ message: "Cannot find name 'foo'." }] }
      );
    });
  const edited = latePayment.LOGIC + '\n// edited';

  beforeEach(() => {
    useAppStore.setState({
      loadSample: vi.fn().mockResolvedValue(undefined),
      modelCto: latePayment.MODEL,
      editorLogicTs: edited,
      logicTs: latePayment.LOGIC,
      compiledLogicJs: 'js',
      compiledModelCto: latePayment.MODEL,
      compilationErrors: [],
      isCompiling: false,
      executionHistory: [],
      executionState: '',
    });
    useDesignV2Store.setState({ view: STEP_ID.logic, selectedTemplate: START_SAMPLES[2].name, helpRailOpen: true });
  });

  it('Next compiles the edited logic and opens Simulate when it compiles', async () => {
    const setLogicTs = compileTo('ok');
    useAppStore.setState({ setLogicTs });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: FOOTER.next }));
    await waitFor(() => expect(useDesignV2Store.getState().view).toBe(STEP_ID.simulate));
    expect(setLogicTs).toHaveBeenCalledWith(edited);
  });

  it('Next stays on Logic and shows the error when the logic does not compile', async () => {
    const setLogicTs = compileTo('error');
    useAppStore.setState({ setLogicTs });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: FOOTER.next }));
    await waitFor(() => expect(screen.getByText(FOOTER.logicBlocked)).toBeInTheDocument());
    expect(useDesignV2Store.getState().view).toBe(STEP_ID.logic);
    expect(screen.getByText("Cannot find name 'foo'.")).toBeInTheDocument();
  });

  it('the stepper goes through the same gate, from any step', async () => {
    const setLogicTs = compileTo('error');
    useAppStore.setState({ setLogicTs });
    useDesignV2Store.setState({ view: STEP_ID.text });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: /Simulate/ }));
    await waitFor(() => expect(setLogicTs).toHaveBeenCalledTimes(1));
    expect(useDesignV2Store.getState().view).toBe(STEP_ID.text);
  });

  it('does not compile again when nothing changed', async () => {
    const setLogicTs = compileTo('ok');
    useAppStore.setState({ setLogicTs, editorLogicTs: latePayment.LOGIC });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: FOOTER.next }));
    await waitFor(() => expect(useDesignV2Store.getState().view).toBe(STEP_ID.simulate));
    expect(setLogicTs).not.toHaveBeenCalled();
  });

  it('compiles again when the model changed since the logic was compiled', async () => {
    const setLogicTs = compileTo('ok');
    const editedModel = latePayment.MODEL + '\n// edited';
    useAppStore.setState({ setLogicTs, editorLogicTs: latePayment.LOGIC, modelCto: editedModel });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: FOOTER.next }));
    await waitFor(() => expect(useDesignV2Store.getState().view).toBe(STEP_ID.simulate));
    expect(setLogicTs).toHaveBeenCalledWith(latePayment.LOGIC);
    expect(useAppStore.getState().compiledModelCto).toBe(editedModel);
  });

  it('compiles again when model.cto is edited while the compile runs', async () => {
    const editedModel = latePayment.MODEL + '\n// edited during compile';
    const compile = compileTo('ok');
    // The first compile sees the original model; the edit lands before it finishes.
    const setLogicTs = vi.fn(async (ts: string) => {
      if (setLogicTs.mock.calls.length === 1) {
        const run = compile(ts);
        useAppStore.setState({ modelCto: editedModel });
        await run;
        useAppStore.setState({ compiledModelCto: latePayment.MODEL });
        return;
      }
      await compile(ts);
    });
    // From the Text step, so the Logic step's own compile-on-arrival stays out of the count.
    useAppStore.setState({ setLogicTs });
    useDesignV2Store.setState({ view: STEP_ID.text });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: /Simulate/ }));
    await waitFor(() => expect(useDesignV2Store.getState().view).toBe(STEP_ID.simulate));
    expect(setLogicTs).toHaveBeenCalledTimes(2);
    expect(useAppStore.getState().compiledModelCto).toBe(editedModel);
  });

  it('stays put when the sources keep changing under every compile', async () => {
    let edits = 0;
    const setLogicTs = vi.fn(async (ts: string) => {
      await compileTo('ok')(ts);
      useAppStore.setState({ modelCto: `${latePayment.MODEL}\n// edit ${++edits}` });
    });
    useAppStore.setState({ setLogicTs });
    useDesignV2Store.setState({ view: STEP_ID.text });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: /Simulate/ }));
    await waitFor(() => expect(setLogicTs).toHaveBeenCalledTimes(3));
    expect((await screen.findAllByText(FOOTER.logicBlocked)).length).toBeGreaterThan(0);
    expect(useDesignV2Store.getState().view).toBe(STEP_ID.text);
  });

  it('shares one compile between moves to Simulate made while it runs', async () => {
    const setLogicTs = compileTo('ok');
    useAppStore.setState({ setLogicTs });
    useDesignV2Store.setState({ view: STEP_ID.text });
    renderLayout();
    const simulate = screen.getByRole('button', { name: /Simulate/ });
    // antd toasts outlive a test's render (and expire mid-test), so watch the call instead.
    const showError = vi.spyOn(message, 'error');
    fireEvent.click(simulate);
    fireEvent.click(simulate);
    await waitFor(() => expect(useDesignV2Store.getState().view).toBe(STEP_ID.simulate));
    expect(setLogicTs).toHaveBeenCalledTimes(1);
    expect(showError).not.toHaveBeenCalled();
    showError.mockRestore();
  });

  it('Back goes through the same gate: it compiles before Simulate opens, and a compile error stays put', async () => {
    const setLogicTs = compileTo('error');
    useAppStore.setState({ setLogicTs });
    useDesignV2Store.setState({ view: STEP_ID.deploy });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: FOOTER.back }));
    await waitFor(() => expect(setLogicTs).toHaveBeenCalledWith(edited));
    await waitFor(() => expect(useAppStore.getState().compilationErrors).toHaveLength(1));
    expect(useDesignV2Store.getState().view).toBe(STEP_ID.deploy);
  });

  it('a failed run in Simulate does not block going back to it', async () => {
    // Compiled and current; a later init/trigger failure left an execution error behind.
    const setLogicTs = compileTo('ok');
    useAppStore.setState({
      setLogicTs,
      editorLogicTs: latePayment.LOGIC,
      compiledLogicJs: 'js',
      compilationErrors: [{ message: 'Execution Error: boom' }],
    });
    useDesignV2Store.setState({ view: STEP_ID.deploy });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: FOOTER.back }));
    await waitFor(() => expect(useDesignV2Store.getState().view).toBe(STEP_ID.simulate));
    expect(setLogicTs).not.toHaveBeenCalled();
  });

  it('drops a move to Simulate when the step changes while it compiles', async () => {
    const { done, finish } = deferredCompile();
    const compile = compileTo('ok');
    const setLogicTs = vi.fn(async (ts: string) => {
      await done;
      await compile(ts);
    });
    useAppStore.setState({ setLogicTs });
    useDesignV2Store.setState({ view: STEP_ID.text });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: /Simulate/ }));
    await waitFor(() => expect(setLogicTs).toHaveBeenCalledTimes(1));
    act(() => useDesignV2Store.setState({ view: FIRST_STEP }));
    finish();
    await waitFor(() => expect(useAppStore.getState().compiledLogicJs).toBe('js'));
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(useDesignV2Store.getState().view).toBe(FIRST_STEP);
  });

  it('drops a move to Simulate when another sample is loaded while it compiles', async () => {
    const { done, finish } = deferredCompile();
    const compile = compileTo('ok');
    const setLogicTs = vi.fn(async (ts: string) => {
      await done;
      await compile(ts);
    });
    useAppStore.setState({ setLogicTs, rebuild: vi.fn().mockResolvedValue(undefined) });
    localStorage.setItem('hasVisitedLogicTour', 'true');
    useDesignV2Store.setState({ view: STEP_ID.text });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: /Simulate/ }));
    await waitFor(() => expect(setLogicTs).toHaveBeenCalledTimes(1));
    // Loading a sample starts a new template generation; the view itself does not change.
    await act(() => realLoadSample(latePayment.NAME));
    finish();
    await waitFor(() => expect(useAppStore.getState().compiledLogicJs).toBe('js'));
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(useDesignV2Store.getState().view).toBe(STEP_ID.text);
  });

  it('passes over Simulate when there is no logic: Next goes to Deploy, Back returns to Logic', async () => {
    const setLogicTs = compileTo('ok');
    useAppStore.setState({ setLogicTs, editorLogicTs: '', logicTs: '', compiledLogicJs: null });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: FOOTER.next }));
    await waitFor(() => expect(useDesignV2Store.getState().view).toBe(STEP_ID.deploy));
    expect(setLogicTs).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole('button', { name: FOOTER.back }));
    expect(useDesignV2Store.getState().view).toBe(STEP_ID.logic);
  });

  it('does not open Simulate when the logic is emptied while it compiles', async () => {
    const compile = compileTo('ok');
    const setLogicTs = vi.fn(async (ts: string) => {
      await compile(ts);
      useAppStore.setState({ editorLogicTs: '' });
    });
    useAppStore.setState({ setLogicTs });
    useDesignV2Store.setState({ view: STEP_ID.text });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: /Simulate/ }));
    await waitFor(() => expect(setLogicTs).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(screen.getByRole('button', { name: /Simulate/ })).toBeDisabled());
    expect(useDesignV2Store.getState().view).toBe(STEP_ID.text);
  });

  it('greys out Simulate in the stepper when there is no logic', () => {
    useAppStore.setState({ editorLogicTs: '', logicTs: '' });
    renderLayout();
    const simulate = screen.getByRole('button', { name: /Simulate/ });
    expect(simulate).toBeDisabled();
    expect(simulate).toHaveTextContent(HEADER.skippedMeta);
  });

  it('other steps are not gated', () => {
    useDesignV2Store.setState({ view: STEP_ID.text });
    renderLayout();
    fireEvent.click(screen.getByRole('button', { name: FOOTER.next }));
    expect(useDesignV2Store.getState().view).toBe(STEP_ID.modelData);
  });
});
