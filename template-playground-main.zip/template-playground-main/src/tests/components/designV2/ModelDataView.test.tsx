import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { render, screen, fireEvent, within } from '@testing-library/react';
import { act } from 'react-dom/test-utils';
import { message } from 'antd';
import '@testing-library/jest-dom';
import { ModelDataView } from '../../../components/designV2/ModelDataView';
import { HELP_RAIL, MODEL_DATA, START, START_SAMPLES, sampleNameFor } from '../../../components/designV2/constants';
import useAppStore from '../../../store/store';
import useDesignV2Store from '../../../store/designV2Store';
import { SAMPLES } from '../../../samples';
import * as latePayment from '../../../samples/latePaymentPenalty';
import { NAME as BLANK_SAMPLE_NAME } from '../../../samples/blank';

/*
 * Monaco is replaced by a plain div: the view under test is the chrome around
 * the editors (file headers, status bars, format / copy / reset) and its
 * wiring to the app store, not the editors themselves.
 */
vi.mock('@monaco-editor/react', () => ({
  useMonaco: () => null,
  Editor: ({ language }: { language: string }) => <div data-testid={`monaco-${language}`} />,
}));

const sampleData = JSON.stringify(latePayment.DATA, null, 2);

describe('sampleNameFor', () => {
  it('maps every Start card to its sample and the blank card to the blank sample', () => {
    for (const card of START_SAMPLES) {
      expect(sampleNameFor(card.name)).toBe(card.sampleName);
    }
    expect(sampleNameFor(START.blankName)).toBe(BLANK_SAMPLE_NAME);
    expect(SAMPLES.map((s) => s.NAME)).toContain(BLANK_SAMPLE_NAME);
  });

  it('returns undefined when nothing or something unknown is selected', () => {
    expect(sampleNameFor(null)).toBeUndefined();
    expect(sampleNameFor('not a card')).toBeUndefined();
  });
});

describe('ModelDataView', () => {
  const setModelCto = vi.fn().mockResolvedValue(undefined);
  const setData = vi.fn().mockResolvedValue(undefined);

  beforeEach(() => {
    vi.clearAllMocks();
    useDesignV2Store.setState({ modelDataPanes: { model: true, data: true }, helpRailOpen: true });
    useAppStore.setState({
      sampleName: latePayment.NAME,
      samples: SAMPLES,
      editorModelCto: latePayment.MODEL,
      modelCto: latePayment.MODEL,
      editorAgreementData: sampleData,
      data: sampleData,
      error: undefined,
      importedData: null,
      // The real setters kick off a debounced rebuild; the wiring is what matters here.
      setModelCto,
      setData,
    });
  });

  const pane = (label: string) => within(screen.getByRole('region', { name: label }));

  it('shows model.cto and data.json side by side, each in its own editor', async () => {
    render(<ModelDataView />);
    const model = pane(MODEL_DATA.model.paneLabel);
    const data = pane(MODEL_DATA.data.paneLabel);
    expect(model.getByText(MODEL_DATA.model.file)).toBeInTheDocument();
    expect(model.getByRole('link', { name: `${MODEL_DATA.model.badge} ↗` })).toHaveAttribute(
      'href',
      MODEL_DATA.model.badgeHref
    );
    expect(data.getByText(MODEL_DATA.data.file)).toBeInTheDocument();
    expect(data.getByText(MODEL_DATA.data.badge)).toBeInTheDocument();
    // The editors are lazy-loaded, so they show up a tick after the chrome.
    expect(await model.findByTestId('monaco-concerto')).toBeInTheDocument();
    expect(await data.findByTestId('monaco-json')).toBeInTheDocument();
  });

  it('shows both status bars green while the store reports no error', () => {
    render(<ModelDataView />);
    expect(pane(MODEL_DATA.model.paneLabel).getByText(MODEL_DATA.model.ok)).toBeInTheDocument();
    expect(pane(MODEL_DATA.data.paneLabel).getByText(MODEL_DATA.data.ok)).toBeInTheDocument();
  });

  it('routes a CTO error to the model pane and marks the data as not checked', () => {
    useAppStore.setState({ error: 'Invalid CTO model: Line 3 column 5' });
    render(<ModelDataView />);
    const model = pane(MODEL_DATA.model.paneLabel);
    // The pane only flags the error; the full message lives in the footer.
    expect(model.getByText(MODEL_DATA.error)).toHaveAttribute('title', 'Invalid CTO model: Line 3 column 5');
    expect(model.queryByText(MODEL_DATA.model.ok)).not.toBeInTheDocument();
    const data = pane(MODEL_DATA.data.paneLabel);
    expect(data.getByText(MODEL_DATA.data.notChecked)).toBeInTheDocument();
    expect(data.queryByText(MODEL_DATA.data.ok)).not.toBeInTheDocument();
  });

  it('routes a JSON or instance error to the data pane', () => {
    useAppStore.setState({ error: 'Invalid JSON data: Unexpected token' });
    render(<ModelDataView />);
    expect(pane(MODEL_DATA.data.paneLabel).getByText(MODEL_DATA.error)).toBeInTheDocument();
    expect(pane(MODEL_DATA.model.paneLabel).getByText(MODEL_DATA.model.ok)).toBeInTheDocument();
  });

  it("routes the template engine's @template error to the model pane", () => {
    useAppStore.setState({ error: 'Failed to find a concept with the @template decorator.' });
    render(<ModelDataView />);
    expect(pane(MODEL_DATA.model.paneLabel).getByText(MODEL_DATA.error)).toBeInTheDocument();
    expect(pane(MODEL_DATA.data.paneLabel).getByText(MODEL_DATA.data.notChecked)).toBeInTheDocument();
  });

  it('does not route template/text errors to the data or model pane', () => {
    useAppStore.setState({ error: 'Unknown property: notAField File text/grammar.tem.md' });
    render(<ModelDataView />);
    expect(pane(MODEL_DATA.model.paneLabel).getByText(MODEL_DATA.model.ok)).toBeInTheDocument();
    expect(pane(MODEL_DATA.data.paneLabel).getByText(MODEL_DATA.data.ok)).toBeInTheDocument();
  });

  it('routes a data error containing "Unknown property" to the data pane, not text', () => {
    useAppStore.setState({ error: 'Data error: the user has an Unknown property in their payload' });
    render(<ModelDataView />);
    expect(pane(MODEL_DATA.data.paneLabel).getByText(MODEL_DATA.error)).toBeInTheDocument();
    expect(pane(MODEL_DATA.model.paneLabel).getByText(MODEL_DATA.model.ok)).toBeInTheDocument();
  });

  it('routes a multiline legacy c: error to the model pane', () => {
    useAppStore.setState({ error: 'Rebuild error\nc: line 3 column 5 Invalid syntax' });
    render(<ModelDataView />);
    const model = pane(MODEL_DATA.model.paneLabel);
    expect(model.getByText(MODEL_DATA.error)).toBeInTheDocument();
    expect(pane(MODEL_DATA.data.paneLabel).getByText(MODEL_DATA.data.notChecked)).toBeInTheDocument();
  });

  it('"format" pretty-prints the data through the store', () => {
    useAppStore.setState({ editorAgreementData: '{"$class":"x","penaltyPercentage":10.5,"capPercentage":55}' });
    render(<ModelDataView />);
    fireEvent.click(pane(MODEL_DATA.data.paneLabel).getByRole('button', { name: MODEL_DATA.format }));
    const pretty = JSON.stringify({ $class: 'x', penaltyPercentage: 10.5, capPercentage: 55 }, null, 2);
    expect(useAppStore.getState().editorAgreementData).toBe(pretty);
    expect(setData).toHaveBeenCalledWith(pretty);
  });

  it('"format" is disabled when data or model editor is empty', () => {
    useAppStore.setState({ editorAgreementData: '   ', editorModelCto: '   ' });
    render(<ModelDataView />);
    expect(pane(MODEL_DATA.data.paneLabel).getByRole('button', { name: MODEL_DATA.format })).toBeDisabled();
    expect(pane(MODEL_DATA.model.paneLabel).getByRole('button', { name: MODEL_DATA.format })).toBeDisabled();
  });

  it('"reset" restores the loaded sample\'s data and is disabled while nothing changed', () => {
    const { unmount } = render(<ModelDataView />);
    expect(pane(MODEL_DATA.data.paneLabel).getByRole('button', { name: MODEL_DATA.reset })).toBeDisabled();
    unmount();

    useAppStore.setState({ editorAgreementData: '{ "capPercentage": 40 }' });
    render(<ModelDataView />);
    const reset = pane(MODEL_DATA.data.paneLabel).getByRole('button', { name: MODEL_DATA.reset });
    expect(reset).toBeEnabled();
    fireEvent.click(reset);
    expect(useAppStore.getState().editorAgreementData).toBe(sampleData);
    expect(setData).toHaveBeenCalledWith(sampleData);
  });

  it('"reset" on an imported template restores the imported data, never a bundled sample of the same name', () => {
    const imported = '{\n  "$class": "org.acme.imported@1.0.0.Late",\n  "capPercentage": 7\n}';
    // The import is named like a bundled sample; reset must still use the imported data.
    useAppStore.setState({ sampleName: latePayment.NAME, importedData: imported, editorAgreementData: '{ "capPercentage": 99 }' });
    const { unmount } = render(<ModelDataView />);
    const reset = pane(MODEL_DATA.data.paneLabel).getByRole('button', { name: MODEL_DATA.reset });
    expect(reset).toBeEnabled();
    fireEvent.click(reset);
    expect(useAppStore.getState().editorAgreementData).toBe(imported);
    expect(setData).toHaveBeenCalledWith(imported);
    expect(setData).not.toHaveBeenCalledWith(sampleData);
    unmount();

    render(<ModelDataView />);
    expect(pane(MODEL_DATA.data.paneLabel).getByRole('button', { name: MODEL_DATA.reset })).toBeDisabled();
  });

  it('"format" on the model re-prints the Concerto file through the store', () => {
    const messy = 'namespace org.acme.latepayment@1.0.0\n@template concept C {   o String fractionalPart }';
    useAppStore.setState({ editorModelCto: messy });
    render(<ModelDataView />);
    fireEvent.click(pane(MODEL_DATA.model.paneLabel).getByRole('button', { name: MODEL_DATA.format }));
    const formatted = useAppStore.getState().editorModelCto;
    expect(formatted).not.toBe(messy);
    expect(formatted).toContain('concept C');
    expect(setModelCto).toHaveBeenCalledWith(formatted);
  });

  it('closing a pane leaves the other one alone, and a chip brings it back', () => {
    render(<ModelDataView />);
    fireEvent.click(screen.getByRole('button', { name: MODEL_DATA.closePane(MODEL_DATA.data.file) }));
    expect(screen.queryByRole('region', { name: MODEL_DATA.data.paneLabel })).not.toBeInTheDocument();
    expect(screen.getByRole('region', { name: MODEL_DATA.model.paneLabel })).toBeInTheDocument();
    expect(useDesignV2Store.getState().modelDataPanes).toEqual({ model: true, data: false });

    fireEvent.click(screen.getByRole('button', { name: MODEL_DATA.reopenPane(MODEL_DATA.data.file) }));
    expect(screen.getByRole('region', { name: MODEL_DATA.data.paneLabel })).toBeInTheDocument();
    expect(
      screen.queryByRole('button', { name: MODEL_DATA.reopenPane(MODEL_DATA.data.file) })
    ).not.toBeInTheDocument();
  });

  it('the last open pane cannot be closed', () => {
    useDesignV2Store.setState({ modelDataPanes: { model: false, data: true } });
    render(<ModelDataView />);
    const close = screen.getByRole('button', { name: MODEL_DATA.closePane(MODEL_DATA.data.file) });
    expect(close).toHaveAttribute('aria-disabled', 'true');
    fireEvent.click(close);
    expect(screen.getByRole('region', { name: MODEL_DATA.data.paneLabel })).toBeInTheDocument();
    expect(useDesignV2Store.getState().modelDataPanes).toEqual({ model: false, data: true });
    expect(
      screen.getByRole('button', { name: MODEL_DATA.reopenPane(MODEL_DATA.model.file) })
    ).toBeInTheDocument();
  });

  it('fills the help rail: live checklist, "why this step" note with links, "how it works" steps', () => {
    render(<ModelDataView />);
    const rail = within(screen.getByRole('complementary'));
    const checks = MODEL_DATA.help.checks;
    expect(rail.getByText(MODEL_DATA.help.checklistTitle)).toBeInTheDocument();
    expect(rail.getByText(HELP_RAIL.count(2, 2))).toBeInTheDocument();
    expect(rail.getByText(checks.modelParses).closest('li')).toHaveClass('nd-check-done');
    expect(rail.getByText(checks.dataValid).closest('li')).toHaveClass('nd-check-done');

    expect(rail.getByText(MODEL_DATA.help.why.note)).toBeInTheDocument();
    for (const link of MODEL_DATA.help.why.links) {
      expect(rail.getByRole('link', { name: `↗ ${link.label}` })).toHaveAttribute('href', link.href);
    }

    fireEvent.click(rail.getByRole('tab', { name: HELP_RAIL.tabHow }));
    for (const step of MODEL_DATA.help.how) {
      expect(rail.getByText(step)).toBeInTheDocument();
    }
  });

  it('the checklist mirrors the store error', () => {
    useAppStore.setState({ error: 'Invalid CTO model: Line 3' });
    render(<ModelDataView />);
    const rail = within(screen.getByRole('complementary'));
    const checks = MODEL_DATA.help.checks;
    expect(rail.getByText(checks.modelParses).closest('li')).toHaveClass('nd-check-error');
    // A broken model means the data cannot be checked: not green, not red.
    expect(rail.getByText(checks.dataValid).closest('li')).toHaveClass('nd-check-todo');
    expect(rail.getByText(checks.needsModel)).toBeInTheDocument();
    expect(rail.getByText(HELP_RAIL.count(0, 2))).toBeInTheDocument();
  });

  it('keeps the checklist green when the error belongs to the text step', () => {
    useAppStore.setState({ error: 'Unknown property: notAField File text/grammar.tem.md' });
    render(<ModelDataView />);
    const rail = within(screen.getByRole('complementary'));
    const checks = MODEL_DATA.help.checks;
    expect(rail.getByText(checks.modelParses).closest('li')).toHaveClass('nd-check-done');
    expect(rail.getByText(checks.dataValid).closest('li')).toHaveClass('nd-check-done');
  });

  it('the help rail can be closed and brought back with the "? Help" chip', () => {
    render(<ModelDataView />);
    fireEvent.click(screen.getByRole('button', { name: HELP_RAIL.close }));
    expect(screen.queryByRole('complementary')).not.toBeInTheDocument();
    expect(useDesignV2Store.getState().helpRailOpen).toBe(false);
    // Both editors keep working without the rail.
    expect(screen.getByRole('region', { name: MODEL_DATA.model.paneLabel })).toBeInTheDocument();
    expect(screen.getByRole('region', { name: MODEL_DATA.data.paneLabel })).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: HELP_RAIL.reopen }));
    expect(screen.getByRole('complementary')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: HELP_RAIL.reopen })).not.toBeInTheDocument();
  });

  describe('copy', () => {
    let clipboardDescriptor: PropertyDescriptor | undefined;

    beforeEach(() => {
      clipboardDescriptor = Object.getOwnPropertyDescriptor(navigator, 'clipboard');
      Object.defineProperty(navigator, 'clipboard', { configurable: true, writable: true, value: undefined });
      vi.spyOn(message, 'success').mockImplementation(vi.fn());
      vi.spyOn(message, 'error').mockImplementation(vi.fn());
    });

    afterEach(() => {
      if (clipboardDescriptor) Object.defineProperty(navigator, 'clipboard', clipboardDescriptor);
      else Reflect.deleteProperty(navigator, 'clipboard');
      vi.restoreAllMocks();
    });

    it('reports failure when the Clipboard API is unavailable', async () => {
      render(<ModelDataView />);
      await act(() => {
        fireEvent.click(pane(MODEL_DATA.model.paneLabel).getByRole('button', { name: MODEL_DATA.copy }));
        return Promise.resolve();
      });
      expect(message.error).toHaveBeenCalledWith(MODEL_DATA.model.copyFailed);
      expect(message.success).not.toHaveBeenCalled();
    });

    it('waits for the write to resolve before reporting success', async () => {
      let resolveWrite!: () => void;
      const pendingWrite = new Promise<void>((resolve) => { resolveWrite = resolve; });
      const writeText = vi.fn(() => pendingWrite);
      Object.assign(navigator, { clipboard: { writeText } });
      render(<ModelDataView />);
      fireEvent.click(pane(MODEL_DATA.model.paneLabel).getByRole('button', { name: MODEL_DATA.copy }));
      expect(writeText).toHaveBeenCalledWith(latePayment.MODEL);
      expect(message.success).not.toHaveBeenCalled();
      expect(message.error).not.toHaveBeenCalled();

      await act(() => { resolveWrite(); return pendingWrite; });
      expect(message.success).toHaveBeenCalledWith(MODEL_DATA.model.copied);
      expect(message.error).not.toHaveBeenCalled();
    });

    it('handles a rejected clipboard write without reporting success', async () => {
      const writeText = vi.fn().mockRejectedValue(new DOMException('Clipboard denied', 'NotAllowedError'));
      Object.assign(navigator, { clipboard: { writeText } });
      render(<ModelDataView />);
      await act(() => {
        fireEvent.click(pane(MODEL_DATA.model.paneLabel).getByRole('button', { name: MODEL_DATA.copy }));
        return Promise.resolve();
      });
      expect(message.error).toHaveBeenCalledWith(MODEL_DATA.model.copyFailed);
      expect(message.success).not.toHaveBeenCalled();
    });

    it('copies the exact editor model and reports success', async () => {
      const model = 'namespace example\n\nconcept Agreement {\n  o String party\n}\n';
      useAppStore.setState({ editorModelCto: model });
      const writeText = vi.fn().mockResolvedValue(undefined);
      Object.assign(navigator, { clipboard: { writeText } });
      render(<ModelDataView />);
      await act(() => {
        fireEvent.click(pane(MODEL_DATA.model.paneLabel).getByRole('button', { name: MODEL_DATA.copy }));
        return Promise.resolve();
      });
      expect(writeText).toHaveBeenCalledTimes(1);
      expect(writeText).toHaveBeenCalledWith(model);
      expect(message.success).toHaveBeenCalledWith(MODEL_DATA.model.copied);
      expect(message.error).not.toHaveBeenCalled();
    });
  });
});
