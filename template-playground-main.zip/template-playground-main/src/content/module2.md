# Module 2

## _Draft a TemplateMark template._

Next define the [TemplateMark](https://github.com/accordproject/markdown-transform?tab=readme-ov-file#templatemark-dom) for the template in the TemplateMark Editor. In this case it is the plain-text word `"Hello"` followed by a space, then the variable `name` followed by `"."`.

```
Hello {{name}}.
```
