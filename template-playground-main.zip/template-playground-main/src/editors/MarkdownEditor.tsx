import { lazy, Suspense, useMemo, useCallback, useEffect, MutableRefObject } from "react";
import useAppStore from "../store/store";
import useThemeName from "../hooks/useThemeName";
import { useMonaco } from "@monaco-editor/react";
import { useCodeSelection } from "../components/CodeSelectionMenu";
import type { editor } from "monaco-editor";
import { registerAutocompletion } from "../ai-assistant/autocompletion";
import { registerEditor, unregisterEditor } from "../utils/editorNavigation";


const MonacoEditor = lazy(() =>
  import("@monaco-editor/react").then((mod) => ({ default: mod.Editor }))
);

export default function MarkdownEditor({
  value,
  onChange,
  onEditorReady,
  editorRef,
}: {
  value: string;
  onChange?: (value: string | undefined) => void;
  onEditorReady?: (editor: editor.IStandaloneCodeEditor) => void;
  editorRef?: MutableRefObject<editor.IStandaloneCodeEditor | null>;
}) {
  const { handleSelection, MenuComponent } = useCodeSelection("markdown");
  const { backgroundColor, textColor, aiConfig, showLineNumbers } = useAppStore((state) => ({
    backgroundColor: state.backgroundColor,
    textColor: state.textColor,
    aiConfig: state.aiConfig,
    showLineNumbers: state.showLineNumbers,
  }));
  const monaco = useMonaco();

  const themeName = useThemeName();

  useEffect(() => {
    if (monaco) {
      const defineTheme = (name: string, base: "vs" | "vs-dark") => {
        monaco.editor.defineTheme(name, {
          base,
          inherit: true,
          rules: [],
          colors: {
            "editor.background": backgroundColor,
            "editor.foreground": textColor,
            "editor.lineHighlightBorder": "#EDE8DC",
            "editorGhostText.foreground": "#9c9a9a"
          },
        });
      };

      defineTheme("lightTheme", "vs");
      defineTheme("darkTheme", "vs-dark");

      monaco.editor.setTheme(themeName);
    }
  }, [monaco, backgroundColor, textColor, themeName]);

  const editorOptions: editor.IStandaloneEditorConstructionOptions = useMemo(() => ({
    minimap: { enabled: false },
    wordWrap: "on" as const,
    automaticLayout: true,
    scrollBeyondLastLine: false,
    lineNumbers: showLineNumbers ? 'on' : 'off',
    inlineSuggest: {
      enabled: aiConfig?.enableInlineSuggestions !== false,
      mode: "prefix",
      suppressSuggestions: false,
      fontFamily: "inherit",
      keepOnBlur: true,
    },
    suggest: {
      preview: true,
      showInlineDetails: true,
    },
    quickSuggestions: false,
    suggestOnTriggerCharacters: false,
    acceptSuggestionOnCommitCharacter: false,
    acceptSuggestionOnEnter: "off",
    tabCompletion: "off",
  }), [aiConfig?.enableInlineSuggestions, showLineNumbers]);

  const handleEditorDidMount = (editorInstance: editor.IStandaloneCodeEditor) => {
    if (editorRef) {
      editorRef.current = editorInstance;
    }
    registerEditor('template', editorInstance);
    editorInstance.onDidChangeCursorSelection(() => {
      handleSelection(editorInstance);
    });

    if (monaco) {
      registerAutocompletion('markdown', monaco);
    }

    if (onEditorReady) {
      onEditorReady(editorInstance);
    }
  };

  useEffect(() => {
    return () => {
      unregisterEditor('template');
    };
  }, []);

  const handleChange = useCallback(
    (val: string | undefined) => {
      if (onChange) onChange(val);
    },
    [onChange]
  );

  return (
    <div className="editorwrapper h-full w-full">
      <Suspense
        fallback={
          <div
            style={{
              height: "100%",
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              backgroundColor,
              color: textColor,
            }}
          >
            Loading Editor...
          </div>
        }
      >
        <MonacoEditor
          options={editorOptions}
          language="markdown"
          height="100%"
          value={value}
          onMount={handleEditorDidMount}
          onChange={handleChange}
          theme={themeName}
        />
      </Suspense>
      {MenuComponent}
    </div>
  );
}
