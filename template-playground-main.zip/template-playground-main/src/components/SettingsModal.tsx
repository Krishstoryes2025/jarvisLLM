import React, { useState } from 'react';
import { Modal, Switch, Collapse, Space, Divider, Typography, ConfigProvider, theme, Row, Col } from 'antd';
import { BulbOutlined, MoonOutlined, RobotOutlined, SettingOutlined } from '@ant-design/icons';
import useAppStore from '../store/store';
import AIConfigSection from './AIConfigSection';
import { colors } from '../utils/theme';

const { Text } = Typography;

const SettingsModal: React.FC = () => {
  const { 
    isSettingsOpen, 
    setSettingsOpen, 
    showLineNumbers,
    setShowLineNumbers,
    backgroundColor,
    toggleDarkMode,
    isDesignV2Enabled,
    setDesignV2Enabled
  } = useAppStore((state) => ({
    isSettingsOpen: state.isSettingsOpen,
    setSettingsOpen: state.setSettingsOpen,
    showLineNumbers: state.showLineNumbers,
    setShowLineNumbers: state.setShowLineNumbers,
    backgroundColor: state.backgroundColor,
    toggleDarkMode: state.toggleDarkMode,
    isDesignV2Enabled: state.isDesignV2Enabled,
    setDesignV2Enabled: state.setDesignV2Enabled,
  }));

  const isDarkMode = backgroundColor === '#121212';
  const [activeKey, setActiveKey] = useState<string | string[]>(['general']);

  const collapseItems = [
    {
      key: 'general',
      label: (
        <Space size={8}>
          <SettingOutlined />
          General
        </Space>
      ),
      children: (
        <Space direction="vertical" size={16} style={{ width: '100%', paddingTop: 4, paddingBottom: 4 }}>
          {/* Dark Mode Toggle */}
          <Row justify="space-between" align="middle" style={{ width: '100%' }}>
            <Col flex="auto">
              <Text strong style={{ display: 'block' }}>Dark Mode</Text>
              <Text type="secondary" style={{ fontSize: 13 }}>
                Toggle between light and dark theme
              </Text>
            </Col>
            <Col>
              <Switch
                data-testid="dark-mode-toggle"
                checked={isDarkMode}
                onChange={toggleDarkMode}
                checkedChildren={<MoonOutlined />}
                unCheckedChildren={<BulbOutlined />}
                aria-label="Toggle dark mode"
              />
            </Col>
          </Row>

          <Divider style={{ margin: 0 }} />

          {/* Line Numbers Toggle */}
          <Row justify="space-between" align="middle" style={{ width: '100%' }}>
            <Col flex="auto">
              <Text strong style={{ display: 'block' }}>Show Line Numbers</Text>
              <Text type="secondary" style={{ fontSize: 13 }}>
                Display line numbers in code editors
              </Text>
            </Col>
            <Col>
              <Switch
                checked={showLineNumbers}
                onChange={setShowLineNumbers}
                aria-label="Toggle line numbers"
              />
            </Col>
          </Row>

          <Divider style={{ margin: 0 }} />

          {/* Opt-out of the default (design v2) layout */}
          <Row justify="space-between" align="middle" style={{ width: '100%' }}>
            <Col flex="auto">
              <Text strong style={{ display: 'block' }}>Use classic playground</Text>
              <Text type="secondary" style={{ fontSize: 13 }}>
                Switch back to the previous single-screen layout. Turn this off to use the new step-by-step design.
              </Text>
            </Col>
            <Col>
              <Switch
                data-testid="classic-playground-toggle"
                checked={!isDesignV2Enabled}
                onChange={(useClassic) => setDesignV2Enabled(!useClassic)}
                aria-label="Use classic playground"
              />
            </Col>
          </Row>
        </Space>
      ),
    },
    {
      key: 'ai',
      label: (
        <Space size={8}>
          <RobotOutlined />
          AI Configuration
        </Space>
      ),
      children: <AIConfigSection />,
    },
  ];

  return (
    <ConfigProvider
      theme={{
        algorithm: isDarkMode ? theme.darkAlgorithm : theme.defaultAlgorithm,
        token: {
          colorPrimary: colors.primary,
        },
      }}
    >
      <Modal
        title="Settings"
        open={isSettingsOpen}
        onCancel={() => setSettingsOpen(false)}
        footer={null}
        width="90%"
        style={{ maxWidth: 520 }}
      >
        <Collapse
          activeKey={activeKey}
          onChange={setActiveKey}
          items={collapseItems}
          bordered={false}
        />
      </Modal>
    </ConfigProvider>
  );
};

export default SettingsModal;