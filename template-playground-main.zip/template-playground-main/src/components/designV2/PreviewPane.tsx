import { useState } from "react";
import { Button, Space, Spin, Typography, message } from "antd";
import DOMPurify from "dompurify";
import useAppStore, { currentRenderRevision } from "../../store/store";
import { downloadMarkdown } from "../../utils/download";
import { saveAgreementPdf } from "../../utils/agreementPdf";
import { PREVIEW } from "./constants";

/**
 * The rendered agreement, shown in place of the editors on the Text and Data
 * steps when their Write | Preview switch is on Preview (see PreviewToggle).
 * It takes the editors' spot rather than floating over them, so the help
 * rail stays in view.
 *
 * Shows the agreement the store last rendered (agreementHtml, sanitised as in
 * the legacy preview). A failed render keeps the last good agreement on the
 * page; the footer carries the error. Until anything has rendered, the page
 * says it is rendering, or that the render failed.
 * The PDF and Markdown buttons render the current sources afresh
 * (store.renderAgreement) and save that, never the page on screen, which
 * keeps the last good render after an error and can lag an edit; a source
 * that doesn't render saves nothing.
 */
const PreviewPane = () => {
  const agreementHtml = useAppStore((s) => s.agreementHtml);
  const agreementRevision = useAppStore((s) => s.agreementRevision);
  const error = useAppStore((s) => s.error);
  const [isSaving, setIsSaving] = useState(false);
  const [isSavingMarkdown, setIsSavingMarkdown] = useState(false);

  /*
   * Stale when an error exists, or when the rendered revision lags current sources.
   * currentRenderRevision() is not reactive, but the pane only mounts/re-renders
   * when switching to Preview or when the store updates, by which point the editor
   * is hidden.
   */
  const isStale = Boolean(error) || Boolean(agreementHtml && agreementRevision !== currentRenderRevision());
  const canDownload = Boolean(agreementHtml && !isStale);

  const saveMarkdown = async () => {
    setIsSavingMarkdown(true);
    try {
      downloadMarkdown(await useAppStore.getState().renderAgreement("markdown"));
    } catch (err) {
      console.error("Markdown export failed:", err);
      void message.error(PREVIEW.markdownFailed);
    } finally {
      setIsSavingMarkdown(false);
    }
  };

  const savePdf = async () => {
    setIsSaving(true);
    try {
      await saveAgreementPdf(await useAppStore.getState().renderAgreement(), PREVIEW.pdfFile);
    } catch (err) {
      console.error("PDF generation failed:", err);
      void message.error(PREVIEW.pdfFailed);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <section className="nd-editor-card nd-preview-card" aria-label={PREVIEW.ariaLabel}>
      <div className="nd-editor-card-head">
        <span className="nd-preview-title">{PREVIEW.title}</span>

        <span
          className={`nd-badge ${isStale ? "nd-badge-amber" : "nd-badge-teal"}`}
          aria-live="polite"
        >
          {isStale ? PREVIEW.staleBadge : PREVIEW.liveBadge}
        </span>

        <div className="nd-spacer" />
        <Button
          type="text"
          size="small"
          disabled={!canDownload}
          loading={isSavingMarkdown}
          onClick={() => void saveMarkdown()}
          title={!canDownload && isStale ? PREVIEW.disabledStale : undefined}
        >
          {PREVIEW.markdown}
        </Button>
        <Button
          type="text"
          size="small"
          disabled={!canDownload}
          loading={isSaving}
          onClick={() => void savePdf()}
          title={!canDownload && isStale ? PREVIEW.disabledStale : undefined}
        >
          {PREVIEW.pdf}
        </Button>
      </div>
      <div className="nd-editor-card-body nd-preview-body">
        {agreementHtml ? (
          <div
            className={`nd-preview-page ${isStale ? "nd-preview-page-stale" : ""}`}
            dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(agreementHtml) }}
          />
        ) : (
          <div className="nd-preview-page">
            <Space direction="vertical" align="center" size={12} style={{ width: "100%" }}>
              {!error && <Spin />}
              <Typography.Text type="secondary">{error ? PREVIEW.failed : PREVIEW.rendering}</Typography.Text>
            </Space>
          </div>
        )}
      </div>
    </section>
  );
};

export default PreviewPane;
